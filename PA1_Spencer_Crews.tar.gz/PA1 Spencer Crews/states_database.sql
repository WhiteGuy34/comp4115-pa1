-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `state_name` varchar(20) DEFAULT NULL,
  `population` int(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avg_temp` int(5) DEFAULT NULL,
  `region` enum('north','south','east','west') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES ('Tennessee',10,1,95,'south'),('Ohio',1000,2,86,'north'),('New York',100,3,78,'north'),('Nebraska',56,4,89,'west'),('Washington',86,5,90,'west'),('California',10002000,6,68,'west'),('Nevada',102000,7,85,'west'),('West Virgina',1089820,8,83,'east'),('Kansas',10320,9,81,'north'),('Michigan',1323207,10,80,'north'),('Florida,123,93,south',NULL,11,NULL,NULL),('Alabama,241586,88,so',NULL,12,NULL,NULL),('Arkansas,236584,89,s',NULL,13,NULL,NULL),('Mississippi,785465,9',NULL,14,NULL,NULL),('Georgia,78574,97,sou',NULL,15,NULL,NULL),('South Carolina,97856',NULL,16,NULL,NULL),('North Carolina,14686',NULL,17,NULL,NULL),('Virgina,84651,83,eas',NULL,18,NULL,NULL),('Kentucky,1581,89,nor',NULL,19,NULL,NULL),('Maryland,54598,87,ea',NULL,20,NULL,NULL),('Delaware,929309,78,e',NULL,21,NULL,NULL),('Pennsylvania,652189,',NULL,22,NULL,NULL),('New Jersey,56165,89,',NULL,23,NULL,NULL),('Connecticut,1896165,',NULL,24,NULL,NULL),('Rhode Island,18951,8',NULL,25,NULL,NULL),('Massachusetts,51789,',NULL,26,NULL,NULL),('New Hampshire,879544',NULL,27,NULL,NULL),('Vermont,18965,87,nor',NULL,28,NULL,NULL),('Maine,518951,98,nort',NULL,29,NULL,NULL),('Indiana,5189515,78,n',NULL,30,NULL,NULL),('Wisconsin,5218951,76',NULL,31,NULL,NULL),('Illinois,21850,70,no',NULL,32,NULL,NULL),('Louisiana,189651,98,',NULL,33,NULL,NULL),('Missouri,1058915,98,',NULL,34,NULL,NULL),('Iowa,158695,98,north',NULL,35,NULL,NULL),('Minnesota,156951,88,',NULL,36,NULL,NULL),('North Dakota,2518965',NULL,37,NULL,NULL),('South Dakota,5158695',NULL,38,NULL,NULL),('Oklahoma,51864,96,no',NULL,39,NULL,NULL),('Texas,1561,95,north',NULL,40,NULL,NULL),('Montana,521786,93,we',NULL,41,NULL,NULL),('Wyoming,218651,92,we',NULL,42,NULL,NULL),('Colorado,21856521,90',NULL,43,NULL,NULL),('New Mexico,585486,89',NULL,44,NULL,NULL),('Arizona,5189651,88,w',NULL,45,NULL,NULL),('Utah,51586,87,west',NULL,46,NULL,NULL),('Idaho,51865,88,west',NULL,47,NULL,NULL),('Oregon,321586,87,wes',NULL,48,NULL,NULL),('',NULL,49,NULL,NULL),('',NULL,50,NULL,NULL),('',NULL,51,NULL,NULL);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-09 19:44:03
