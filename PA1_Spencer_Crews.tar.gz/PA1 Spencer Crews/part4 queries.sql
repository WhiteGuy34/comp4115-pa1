
select customername from customers where customerNumber in (select customerNumber from orders where orderDate > 2015/02/01);

select city,state from customers where customerNumber in (select customerNumber from orders where orderDate > 2014/1/01);

select quantityOrdered,priceEach from orderdetails where orderNumber in (select orderNumber from orders where customerNumber in (select customerNumber from customers where state = "MA"));

select employees.lastname, employees.firstname from employees join offices on employees.officecode = offices.officecode where offices.city = "San Francisco";

select products.productcode, products.productname, productlines.image from products join productlines on products.productline = productlines.productline where productcode = "S24_2887";

select customers.customerName, customers.addressLine1, orders.status from customers join orders on customers.customerNumber = orders.customerNumber; 

select customers.customerName, customers.addressLine1, orders.status from customers join orders on customers.customerNumber = orders.customerNumber where orders.status = "In process"; 

select payments.customernumber, payments.paymentdate, payments.amount from payments where customerNumber in(select customernumber from orders where ordernumber = 10425);
