use us_states;
select * from states;
